/// <reference types="Cypress" />

class LoginPOM {

    LoginIconModal() {
        return cy.get('#login2')
    }

    LogoutIconModal() {
        return cy.get('#logout2')
    }

    LoginUsernameInput() {
        return cy.get('#loginusername')
    }

    LoginPasswordInput() {
        return cy.get('#loginpassword')
    }

    LoginBtn() {
        return cy.get('#logInModal').find('.btn-primary')
    }

}

export default new LoginPOM();
  