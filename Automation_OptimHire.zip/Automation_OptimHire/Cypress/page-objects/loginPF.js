/// <reference types="Cypress" />

import LoginPOM from '../page-object-model/loginPOM'

class LoginPF {

    LoginWithExistUser(user, pass) {
        cy.intercept('POST', 'https://api.demoblaze.com/login').as('Login')
        cy.intercept('POST', 'https://api.demoblaze.com/check').as('check')
        cy.intercept('POST', 'https://api.demoblaze.com/entries').as('entries')
        cy.intercept('POST', 'https://hls.demoblaze.com/index.m3u8').as('index')
        LoginPOM.LoginIconModal().click()
        LoginPOM.LoginUsernameInput().should('be.visible').clear().type(user)
        LoginPOM.LoginPasswordInput().should('be.visible').clear().type(pass)
        LoginPOM.LoginBtn().click()
        cy.wait('@Login')
        cy.wait('@check')
        cy.wait('@entries')
        cy.wait('@index')
    }

    Logout() {
        LoginPOM.LogoutIconModal().click()
    }
    
    LoginWithInvalidUser(user, pass) {
        cy.intercept('POST', 'https://api.demoblaze.com/login').as('Login')
        LoginPOM.LoginIconModal().click()
        LoginPOM.LoginUsernameInput().should('be.visible').clear().type(user)
        LoginPOM.LoginPasswordInput().should('be.visible').clear().type(pass)
        LoginPOM.LoginBtn().click()

        cy.wait('@Login').then((loginMsg) => {
            expect(loginMsg.response.body).to.have.property('errorMessage', 'User does not exist.');
        });

    }
    
}
  
export default new LoginPF();
  