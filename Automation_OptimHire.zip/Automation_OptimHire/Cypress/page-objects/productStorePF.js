/// <reference types="Cypress" />

import ProductStorePOM from '../page-object-model/productStorePOM'

class ProductStorePF {

    GoToCategory(cat) {
        cy.intercept('POST', 'https://api.demoblaze.com/bycat').as('bycat')
        ProductStorePOM.GetToCategory(cat).should('be.visible').click({force:true})
        cy.wait('@bycat')
    }

    AddProductToCart(num) {
        cy.intercept('POST', 'https://api.demoblaze.com/addtocart').as('addToCart')
        ProductStorePOM.GetTotalProduct().eq(num).should('be.visible').click()
        ProductStorePOM.GetaddToCartBtn().click()
        cy.wait('@addToCart')
    }
    
}


export default new ProductStorePF();
  