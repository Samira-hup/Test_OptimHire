/// <reference types="Cypress" />

import cartPOM from '../page-object-model/cartPOM'

class CartPF {
    
    Visit() {
        cy.visit('https://www.demoblaze.com/cart.html')
    }

    RemoveItem(num) {
        cy.intercept('POST', 'https://api.demoblaze.com/deleteitem').as('deleteitem')
        cartPOM.GetCartItem().eq(num).find('a[onclick*="deleteItem"]').click()
        cy.wait('@deleteitem')
    }

    PlaceOrder() {
        cartPOM.GetPlaceOrderBtn().click()
    }

    FillPlaceOrderFields() {
        
        var orderFields = new Object();

        orderFields.name = 'Samira'
        orderFields.country = 'Dominican Republic'
        orderFields.city = 'Santo Domingo'
        orderFields.creditcard = '4111111111111111'
        orderFields.month = '02'
        orderFields.year = '2025'

        cartPOM.getNameInput().type(orderFields.name)
        cartPOM.getCountryInput().type(orderFields.country)
        cartPOM.getCityInput().type(orderFields.city)
        cartPOM.getCreditCardInput().type(orderFields.creditcard)
        cartPOM.getMonthInput().type(orderFields.month)
        cartPOM.getYearInput().type(orderFields.year)
        cartPOM.getTotalAmmount().invoke('text').then(txt => { orderFields.total = txt.replace('Total: ', '');})

        cy.wrap(orderFields).as('OF')

    }

    PurchaseOrder() {
        cartPOM.getPurchaseBtn().click()
    }

    ValidateOrderDetails() {
        cy.get('p.lead.text-muted').invoke('text').as('textoElementoP');

        cy.get('@OF').then( OrderFields => {
            cy.get('@textoElementoP').should('include', `Name: ${OrderFields.name}`);
            cy.get('@textoElementoP').should('include', `Card Number: ${OrderFields.creditcard}`);
            cy.get('@textoElementoP').should('include', `Amount: ${OrderFields.total}`);
        })
    }
    
}


export default new CartPF();
  