/// <reference types="Cypress" />

import HomePage from '../page-objects/homePagePF';
import SignUpPF from '../page-objects/signUpPF';
import LoginPF from '../page-objects/loginPF';
import productStorePF from '../page-objects/productStorePF';
import cartPF from '../page-objects/cartPF'

describe('Test 1: Sign Up, Log In, and Invalid Login', () => {

  beforeEach(() => {
    cy.intercept('GET', 'https://api.demoblaze.com/entries').as('entries')
    cy.intercept('GET', 'https://hls.demoblaze.com/index.m3u8').as('index')
    HomePage.visit()
    cy.wait('@entries')
    cy.wait('@index')
  });

  it('Test 1: Login and Sign up test', () => {
    SignUpPF.SignUpNewUser()
    //SignUpPF.SignUpExistUser()
    LoginPF.LoginWithExistUser('AutomationSamira', 'Samira123')
    LoginPF.Logout()
    LoginPF.LoginWithInvalidUser('aasbuyfbasuyfbasub', 'sabudfabsufasbu')
  });

  it('Test 2: Login, add 2 phones to cart, remove 1 and pay', () => {
    cy.wait(1000)
    LoginPF.LoginWithExistUser('AutomationSamira', 'Samira123')
    productStorePF.GoToCategory('Phone')
    productStorePF.AddProductToCart(1)
    HomePage.visit()
    productStorePF.GoToCategory('Phone')
    productStorePF.AddProductToCart(2)
    cartPF.Visit()
    cartPF.RemoveItem(1)
    cartPF.PlaceOrder()
    cartPF.FillPlaceOrderFields()
    cartPF.PurchaseOrder()
  });

  it('Test 3: Validate Order Details', () => {
    cy.wait(1000)
    LoginPF.LoginWithExistUser('AutomationSamira', 'Samira123')
    productStorePF.GoToCategory('Laptops')
    productStorePF.AddProductToCart(1)
    HomePage.visit()
    productStorePF.GoToCategory('Phone')
    productStorePF.AddProductToCart(2)
    cartPF.Visit()
    cartPF.RemoveItem(1)
    cartPF.PlaceOrder()
    cartPF.FillPlaceOrderFields()
    cartPF.PurchaseOrder()
    cartPF.ValidateOrderDetails()
  });

  it('Test 4: Validate subcategories', () => {
    cy.intercept('POST', 'https://api.demoblaze.com/bycat').as('category')
    LoginPF.LoginWithExistUser('AutomationSamira', 'Samira123')
    productStorePF.GoToCategory('Phone')
    cy.wait('@category').then((response) => {
      expect(response.status).to.eq(200);
      const responseData = response.body;
      responseData.forEach((item) => {
        expect(item.cat).to.equal('phone');
      });
    });
    
  });


});

